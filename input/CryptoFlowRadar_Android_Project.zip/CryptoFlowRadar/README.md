# CryptoFlow Radar (Android APK project)

A no-trading, read-only Android dashboard using public Binance USDⓈ-M Futures endpoints. Includes live ticker scanner, volume-spike scoring, an estimated flow proxy, signal reasons, a simple BTC chart, heatmap, and in-app price alerts.

## Build the APK
1. Install Android Studio (current stable) and its Android SDK Platform 35.
2. Open this folder (`CryptoFlowRadar`) in Android Studio.
3. Allow Gradle sync to finish. If prompted, install the Android Gradle Plugin / SDK components.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Output is usually `app/build/outputs/apk/debug/app-debug.apk`. Install it on your Android phone and allow notifications.

Alternatively, from a machine with JDK 17, Android SDK and compatible Gradle installed:
`gradle assembleDebug`
(There is no Gradle wrapper included in this starter project.)

## Run the web dashboard separately
Open `app/src/main/assets/index.html` in a browser with internet access. Some browsers may restrict API requests from `file://`; if so, serve that folder with Python:
`python -m http.server 8000 --directory app/src/main/assets`
then open `http://127.0.0.1:8000`.

## Data and limitations
- Uses public endpoints `https://fapi.binance.com/fapi/v1/ticker/24hr`, `/fapi/v1/klines`, and `/fapi/v1/ticker/price`; no API key is required.
- Estimated capital flow is a **proxy**, not verified exchange-wide inflow/outflow: quote volume × price change direction. Public ticker data cannot reveal all participant identities or exact net capital movement.
- Signal scores are heuristic indicators, not predictions or financial advice. Futures trading can cause rapid losses. The app does not place trades and stores no API keys.
- Price alerts work while the app is open; Android notification permission is requested at launch. Background alerts after the app is closed are not implemented.
